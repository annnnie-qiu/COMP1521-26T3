	.text

main:
	# i - $t0
	# j - $t1
	# for (int i = 1; i <= 10; i++) {
	# int i = 1; i = $t0 = 1
	li 	$t0, 1
	# while (i <= 10) {
	# 1. opposite condition 
	# 2. have a label before the condition
first_while_loop_condi:
	# i > 10 goto return_0
	bgt 	$t0, 10, return_0
	# inside first while loop
		# int j = 0; j = $t1 = 0
	li 	$t1, 0

	# print "here"
second_while_loop_condi:
	# while (j < i) { - j >= i goto print_new_line
	bge 	$t1, $t0, print_new_line
	# we are in the second for loop
	# printf("*");
	li	$v0, 11
	li 	$a0, '*'
	syscall
	#  j++; - j = j + 1
	addi	$t1, $t1, 1
	#         } - goto the second condition
	j 	second_while_loop_condi

print_new_line:
	# printf("\n");
	li 	$v0, 11
	li 	$a0, '\n'
	syscall

	# i++;
	addi 	$t0, $t0, 1
	j 	first_while_loop_condi

return_0:
	# return 0;
	li 	$v0, 0
	jr 	$ra

	.data