	.text
# all the function
#include <stdio.h> - nothing

# int main(void) { - function name into label name
main:
	# int x, y;
	# x - $t0
	# y - $t1
	# printf("Enter a number: ");
	li 	$v0, 4		# $v0 = 4;
	la 	$a0, numbers
	syscall

	# scanf("%d", &x);
	li	$v0, 5
	syscall 
	# 15 - $v0 = 15
	# $t0 = $v0
	move 	$t0, $v0

	# y = x * x; - mul 	y, x, x
	mul	$t1, $t0, $t0

	# printf("%d\n", y);
	li	$v0, 1
	move 	$a0, $t1
	syscall

	# print the new line - char
	li 	$v0, 11
	la	$a0, '\n'
	syscall

	# new_line string
	li	$v0, 4
	la 	$a0, new_line
	syscall

	# return 0; - $V FOR return
	li 	$v0, 0
	jr 	$ra

	.data
numbers:
	.asciiz "Enter a number: "
new_line:
	.asciiz "\n"