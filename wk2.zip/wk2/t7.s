	.text

main:
	# x - $t0
	# int x = 24; 
	li	$t0, 24
main__while:
	# while (x < 42) {
	# -> x >= 42 goto main__end
	bge 	$t0, 42, main__end
	# inside the while loop - print
	li	$v0, 1
	move 	$a0, $t0
	syscall

	# print new line

main__inc:
	#  x += 3; -> x = x + 3
	add	$t0, $t0, 3
	b 	main__while

main__end:
	jr 	$ra


	.data