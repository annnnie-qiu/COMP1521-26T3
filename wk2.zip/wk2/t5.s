	.text
#include <stdio.h>
#define SQUARE_MAX 46340
SQUARE_MAX = 46340

# int main(void) {
main:
	# printf("Enter a number: ");
	li 	$v0, 4		# $v0 = 4;
	la 	$a0, numbers
	syscall

	# scanf("%d", &x);
	li	$v0, 5
	syscall 
	# 15 - $v0 = 15
	# $t0 = $v0
	move 	$t0, $v0

	# if (x > SQUARE_MAX) { ->
	# x <= SQUARE_MAX goto main__else
	ble 	$t0, SQUARE_MAX, main__else
	# we are inside the if condition!!
	# printf("square too big for 32 bits\n");
	li	$v0, 4
	la	$a0, if_condi
	syscall
	b	main__end
	# j	main__end


main__else:
	# y = x * x;
	mul 	$t1, $t0, $t0
	# printf("%d\n", y);
	li	$v0, 1
	move	$a0, $t1
	syscall
main__end:
# return 0;
	li 	$v0, 0
	jr	$ra

	.data
numbers:
	.asciiz "Enter a number: "
if_condi:
	.asciiz "square too big for 32 bits\n"
