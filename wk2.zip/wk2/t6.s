	.text
# int main(void) {
main:

	li 	$v0, 4
	la 	$a0, numbers
	syscall

	li 	$v0, 5
	syscall
	move 	$t0, $v0	# $t0 = x 

	# if (x > 100 && x < 1000) {
	# x <= 100 goto main__else
	ble 	$t0, 100, main__else
	# need to comapre the second condi
	bge 	$t0, 1000, main__else
	 	# inside the if condi 
	
	# break to the end

main__else:
	# print



	.data
numbers:
	.asciiz "Enter a number: "